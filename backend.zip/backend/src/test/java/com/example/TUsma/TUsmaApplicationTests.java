package com.example.TUsma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TUsmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
